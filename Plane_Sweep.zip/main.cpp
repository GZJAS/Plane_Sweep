#include <opencv2\opencv.hpp>
#include <iostream>
#include <string>
#include <cstdlib>
#include "CoordinateChange.h"
#include "myData.h"
using namespace cv;
using namespace std;
int main()
{
	//myData data;
	//data.InitRTs();
	CvMat *mat01,*mat02,*mat03;

	mat01 = cvCreateMat( 3, 4, CV_64FC1);
	mat02 = cvCreateMat( 4, 1, CV_64FC1);
	mat03 = cvCreateMat( 3, 1, CV_64FC1);

	double a[] = {-636.539190953, 604.807339337, -384.272907729, -5.98290380763, 
		-297.696617254, 483.468995474, 629.502425436, -28.8449084572, 
		0.0607332990675, 0.993263090684, -0.0986988212285, -0.0997322032072 };
	cvInitMatHeader( mat01, 3, 4, CV_64FC1, a);

	for( int i = 0;i < 3;i++)
	{
		for( int j = 0; j< 4;j++)
		{
			std::cout<<CV_MAT_ELEM(* mat01,double,i,j)<<" ";
		}
		std::cout<<std::endl;

	}

	mat01 = change(mat01);

	for( int i = 0;i < 3;i++)
	{
		for( int j = 0; j< 4;j++)
		{
			std::cout<<CV_MAT_ELEM(* mat01,double,i,j)<<" ";
		}
		std::cout<<std::endl;

	}


	double b[] = {0, 0, 0,1};

	cvInitMatHeader( mat02, 4, 1, CV_64FC1, b);

	cvMatMulAdd( mat01, mat02, 0, mat03);

	double x,y,z;
	z = CV_MAT_ELEM(* mat03,double,2,0);
	x = CV_MAT_ELEM(* mat03,double,0,0);
	y = CV_MAT_ELEM(* mat03,double,1,0);


	x = x/z;
	y = y/z;
	z = 1;

	for( int i = 0;i < 3;i++)
	{
		for( int j = 0; j< 1;j++)
		{
			std::cout<<CV_MAT_ELEM(* mat03,double,i,j)<<" ";
		}
		std::cout<<std::endl;

	}

	cout << x << " " << y << " " << z << endl;


	system("pause");

	waitKey();

	return 0;
}

//int main()
//{
//	myData data;
//	data.InitRTs();
//	data.computeTrueRTs();
//	data.computVC_Score();
//	for (int n = 0 ; n < 56 ; n++)
//	{
//		for( int i = 0;i < 3;i++)
//		{
//			for( int j = 0; j< 4;j++)
//			{
//				std::cout<<data.RTs[n][i*4+j]<<" ";
//			}
//			std::cout<<std::endl;
//
//		}
//	}
//	system("pause");
//	return 0;
//}