#include <opencv2\opencv.hpp>

CvMat *change(CvMat *original);