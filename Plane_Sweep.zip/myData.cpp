#include "myData.h"
#include <fstream>
#include <string>
#include "CoordinateChange.h"

using namespace cv;


void myData::InitRTs()
{
	fstream read;
	int i ;
	stringstream ss;
	string i_str;
	string path;
	string strLine;

	for (i=1 ; i<57 ; i++)
	{
		ss<<i;
		ss>>i_str;
		ss.clear();
		ss.str("");
		if (i<10)
		{
			path = "F:/��ά�ؽ�/txt/0000000"+ i_str + ".txt";

		}
		else
		{
			path = "F:/��ά�ؽ�/txt/000000"+ i_str + ".txt";

		}
		read.open(path);
		getline(read,strLine);
		int n = 0;
		while(getline(read,strLine))
		{
			istringstream is(strLine);
			is >> RTs[i-1][n] >> RTs[i-1][n+1] >> RTs[i-1][n+2] >> RTs[i-1][n+3];
			n += 4;
		}

		read.close();
	}
}

void myData::computeTrueRTs()
{
	for (int i=0 ; i<56 ; i++)
	{
		CvMat *rt = cvCreateMat( 3, 4, CV_64FC1);
		//cvInitMatHeader(rt,3,4,CV_64FC1,a);
		cvInitMatHeader(rt,3,4,CV_64FC1,RTs[i]);
		rt = change(rt);
		cvReleaseMat(&rt);

	}

}

void myData::computVC_Score()
{

	CvMat *rt = cvCreateMat( 3, 4, CV_64FC1);
	
	cvInitMatHeader(rt,3,4,CV_64FC1,RTs[0]);

	double b[] = {1, -3,3,1};
	CvMat *three_d_point = cvCreateMat( 4, 1, CV_64FC1);
	cvInitMatHeader( three_d_point, 4, 1, CV_64FC1, b);

	CvMat *two_d_point = cvCreateMat(3,1,CV_64FC1);

	cvMatMulAdd( rt, three_d_point, 0, two_d_point);
	float x,y,z;
	z = CV_MAT_ELEM(* two_d_point,float,2,0);
	x = CV_MAT_ELEM(* two_d_point,float,0,0);
	y = CV_MAT_ELEM(* two_d_point,float,1,0);


	x = x/z;
	y = y/z;
	z = 1;


	Mat img = imread("F:/��ά�ؽ�/visualize/00000001.jpg");
	int r_color,g_color,b_color;
	r_color = img.at<Vec3b>(x,y)[2];
	g_color = img.at<Vec3b>(x,y)[1];
	b_color = img.at<Vec3b>(x,y)[0];


}