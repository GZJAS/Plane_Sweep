#pragma  once
#include <vector>
using namespace std;

struct VC_Point
{
	double Score;
	double z;
	double R;
	double G;
	double B;
};

class myData
{
private:

public:
	void InitRTs();
	double RTs[56][12];
	vector<VC_Point> VC_Points;
	void computeTrueRTs();
	void computVC_Score();
};