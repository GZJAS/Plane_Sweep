#include "CoordinateChange.h"


CvMat *change(CvMat *original)
{
	CvMat *mat_k,*mat_k_inv,*mat_rt,*mat_inv_e;
	mat_rt = cvCreateMat(3,4,CV_64FC1);
	mat_inv_e = cvCreateMat(4,4,CV_64FC1);

	double _e[] = {-1,0,0,0,
		0,-1,0,0,
		0,0,-1,0,
		0,0,0,-1};	
	cvInitMatHeader(mat_inv_e,4,4,CV_64FC1,_e);

	mat_k =  cvCreateMat( 3, 3, CV_64FC1);

	double _k[] = {-800,0,599.5,0,800,399.5,0,0,1};
	cvInitMatHeader( mat_k, 3, 3, CV_64FC1, _k);



	mat_k_inv = cvCreateMat( 3, 3, CV_64FC1);
	cvInvert(mat_k, mat_k_inv, CV_SVD);




	cvmSet(mat_k,0,0,800);



	cvMatMulAdd( mat_k_inv, original, 0, mat_rt);


	cvMatMulAdd( mat_rt, mat_inv_e, 0, mat_rt);



	cvMatMulAdd(mat_k,mat_rt,0,original);

	return original;

}